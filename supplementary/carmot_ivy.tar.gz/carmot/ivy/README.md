# Verifying Quark

## Decision choices in modelling HappensBeforeEqual

### Decision 1
In the modelling of the `happensBeforeEqualNoRoot` we've created an instance where the `init` does not create the `graph.root` vertex. 

Is this the right way to proceed? 

This suggests that the `branch_imp.zero` should be created/initialized only after the vertex `graph.root` is initialized. 

### Decision 1.1
We need to ensure that in the definition of `commit` and `fork`, there should exist a null-branch. 



### Decision 2 : 
In the modelling of `happensBeforeEqual` we try to `init` with the `graph.root` existing as a `graph.vertex` with `link(root,root)` existing. 

what does this buy us? 
It seems to be better to initialize with the `root`, as that is the manner in which we have defined the Quark model. 

Additionally, we seem to be using the `version` type in Quark, to generated a `total-ordered version number sequene` that has the `successor()` and `predessor()` functions defined. However, the `graph.vertex` **does not** have any such ordered sequence available. 

By defining two different structures that impose an order/structure on `type version`
```
instantiate version_imp : total_order(version)
...
instantiate graph : happensBeforeEqual(version)
```
we implicitly assume that `version_imp.zero` is synonymous with `graph.root`. However, this can possibly lead to errors. 


This has been resolved!

## Decision 3: 


### Decision 3.1
The scenario where the `versionValueMap` and the `headVersionOfBranch` has occupants/definitions even though the corresponding `graph.vertex` or the `setBranches` isn't initilaized. 

[figure_001.png]
```
    invariant exists B. headVersionOfBranch(B) -> setBranches(B)
    invariant exists V. versionValueMap(V) -> graph.vertex(V)
```

### Decision 3.2

```
    # This is dangerous. It produces a result that makes solver generate `inconclusive` results. 
    #invariant exists V:version, Y:value. versionValueMap(V)=Y -> graph.vertex(V)
```

### Decision 3.3
Should the `versionValueMap` be encoded as a `function` or a `relation` ?


### Decision 3.4
There's some issue with `lcAncestorRel`. It seems to indicate that there are multiple ancestors. 

**Is there a concern in the way that it updates the lca?**
instead of calling `updateLCA()` separately, should we just do the required update within the action itself? 

`fork` is showing errors. `fastfwd` passed the constraints, which means even `merge` will pass it. 

**need to address fork asap.**


## Issue 1: 
Multiple branches in `git.setBranches` are mapped by `headVersionOfBranch()` to `graph.root`.


## Issue 3: 
The fact that link(X,Y)`` doesn't mean that both are vertices already. 

```
	action connect_upstream(src:t,dest:t)={

	  	if (exists Z:t. (Z~= src & vertex(Z) & link(Z,src)) ) { 
	  		assert (vertex(Z) & link(Z,src));
	  		link(Z,dest) := true; 
	  	};
	}

	action connect_downstream(src:t,dest:t)={

	  	if (exists Z:t. (  vertex(Z) & link(dest,Z) & (Z~= dest)) ) { 
	  		
	  			link(src,Z) := true; 

	  		
  		};

	}


```
Modify these to changes to specification after `action-name`.

```


```


## Issue 4: 
The N and C function are updated based on some fixed rules. 
They aren't defined/constructed arbitrarily. They are maps that are updated based on the rules. And hence, they shall follow some specific non-trivial properties. 



## Proving Progress 

### Version 1: 


### Version 2: 

Here is an alternative formulation of progress that claims eventual convergence:
Add an ID transition to the system that does nothing, i.e., relates every system state S to itself. This transition represents a stutter step where system does not make progress due to transient conditions such as network partitions.
Define a new transition relation R as union of FastFwd, Merge, and ID steps. 
Let S be a state of the system such that:
S is well-formed, i.e., every pair of branches has a unique LCA and commit sets modulo LCA are disjoint, and 
S has not yet converged, i.e., not all commits are present on all the branches.
Progress should now assert that there exists a (possibly infinite) sequence of R steps that take the state S to a well-formed and convergent state S’. In other words, the system starting at state S will eventually convergence.

I think the second one requires you to do temporal reasoning in Ivy.