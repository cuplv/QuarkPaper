# Debugging Errors


## E 1.  

```
$ ivy_check isolate=store quarkRefineImplement_2.ivy 

Isolate store:
store.localHeadVersionOfBranchMapRel(fml:dest,B,X) := ((store.localHeadVersionOfBranchMapRel(fml:src,B,X) & store.localHeadVersionOfBranchMapRel(fml:dest,B,X)) | (store.localHeadVersionOfBranchMapRel(fml:src,B,Y) & store.localHeadVersionOfBranchMapRel(fml:dest,B,X) & X > Y) | (store.localHeadVersionOfBranchMapRel(fml:src,B,X) & store.localHeadVersionOfBranchMapRel(fml:dest,B,Y) & X > Y))
quarkRefineImplement_2.ivy: line 759: error: multiply assigned: store.localHeadVersionOfBranchMapRel

```


From `ivy/ivy_actions.py`
```

    subst_action, null_update, exist_quant, hide_state, hide_state_map, constrain_state, bind_olds_action, old
from ivy_utils import unzip_append, IvyError, IvyUndefined, distinct_obj_renaming, dbg

        lhs_vars = used_variables_ast(lhs)
        if any(v not in lhs_vars for v in used_variables_ast(rhs)):
            print self
            raise IvyError(self,"multiply assigned: {}".format(lhs.rep))


        type_check(domain,rhs)
        if is_individual_ast(lhs) != is_individual_ast(rhs):

```

### Final Solution that works

```
	action sync2(src:replicaID, dest:replicaID)={
		# Ensure that all the localVersions in all replicas are updated into the local replica. 
		assume (graphVersions(src,X) -> graphVersions(dest,X) );
		assume (graphLinks(src,X,Y) -> graphLinks(dest,X,Y) );

		# Ensure that the Head is latest
		assume ( headVersionOfBranchMapRel(dest,B,X) & headVersionOfBranchMapRel(src,B,Y) & ( (X>Y) | (X=Y) ));

		# Ensure that the local-happens-before-graph captures the properties also. 
		assume (graph_hb.vertex(src,X) -> graph_hb.vertex(dest,X));
		assume (graph_hb.link(src,X,Y) -> graph_hb.link(dest,X,Y));
		call graph_hb.updateTransitivity(dest);
		call graph_hb.updateAntiSymmetry(dest);

	}

```
By adopting the method of defining `sync` based on the definition of `synchronization`, the code seems to be working. However, when we attempt to define `sync` explicitly as below in `Solution 2`, there's some errors that show up. 

**NOTE: This difference in functionality needs to be examined. Maybe we can do this later, after completing the other tasks that we have for PLDI 2022**.



### Solution 2
Addressed this by formulating it in the following manner: 

```
		# synchronize the Branch-Head

		# ORIG FORMULATION: 
		# We are trying to ensure that the Head-Versions are updated to capture the latest/newest information contained in either of the replicas. 
		# 1. Either the braches have same head-versions. 
		# 2. Either the source-branch has newest head-version 
		# 3. Or, the dest-branch has newest head-version. 
		#headVersionOfBranchMapRel(dest,B,X) := (headVersionOfBranchMapRel(src,B,X) & headVersionOfBranchMapRel(dest,B,X) ) | (headVersionOfBranchMapRel(src,B,Y) & headVersionOfBranchMapRel(dest,B,X) & (X > Y)) | (headVersionOfBranchMapRel(src,B,X) & headVersionOfBranchMapRel(dest,B,Y) & (X > Y));



		# ----	----	----	----	----	----	----	
		# First Identify the branches which satisfy a particular condition. And then use that appropriately. 


		# capture the Branches for which (dest-X = src-Y)		
		toBeModified(B) := true; # reset
		toBeModified(B) := toBeModified(B) & setBranches(B) & ~(exists X. forall B,Y. (headVersionOfBranchMapRel(src,B,Y) & headVersionOfBranchMapRel(dest,B,X) & ( (X < Y) | (X>Y) ) ) );

		# ----
		# capture the Branches for which (dest-X > src-Y)		
		toBeModified1(B) := true; # reset
		toBeModified1(B) := toBeModified1(B) & setBranches(B) & ~(exists X. forall B,Y. (headVersionOfBranchMapRel(src,B,Y) & headVersionOfBranchMapRel(dest,B,X) & ( (X < Y) | (X=Y) ) ) );

		# ----		
		# capture the Branches for which (src-X > dest-Y)
		toBeModified2(B) := true; # reset
		toBeModified2(B) := toBeModified2(B) & setBranches(B) & ~(exists X. forall B,Y. (headVersionOfBranchMapRel(src,B,X) & headVersionOfBranchMapRel(dest,B,Y) & ( (X < Y) | (X=Y) )  ) );

		# ----
		# For the appropriate condition, just use the Branch-information and the Target Tuple.
		headVersionOfBranchMapRel(dest,B,X) := toBeModified(B) & ~toBeModified1(B) & ~toBeModified2(B) & headVersionOfBranchMapRel(dest,B,X)  | ~toBeModified(B) & toBeModified1(B) & ~toBeModified2(B)  & headVersionOfBranchMapRel(dest,B,X)  | ~toBeModified(B) & ~toBeModified1(B) & toBeModified2(B) & headVersionOfBranchMapRel(src,B,X) ;

		# reset
		toBeModified(B) := true;
		toBeModified1(B) := true;
		toBeModified2(B) := true;
 
```


Encountered verification errors for the following invariants

```
#[Issue 1] : There exists (branches assigned to replicas) which do NOT have a head-version.

# if [branch b exists] then [that branch has a HEAD version]
# TODO: This is risky: SKOLEM. 
invariant exists X:version. setReplicas(R) & setBranches(B) & branchToReplicaRel(B,R) -> headVersionOfBranchMapRel(R,B,X) &  graphVersions(R,X)  & setVersions(X) 

```


```
#[Issue 2] : The commits are not monotonically increasing for the branches

# monotonically increasing commits
invariant graph_hb.link(R,X,Y) & ( graph_hb.vertex(R,X) & graph_hb.vertex(R,Y) & setReplicas(R) ) & commitsInVersion(X,A) & commitsInVersion(Y,B) -> (setCommitIDs(A) -> setCommitIDs(B) )

```

### Issue 1. 

What if the description of the invariant itself is NOT correct. Maybe we need to use the following invariant, to encode the following property: `if [branch b exists in a replica] then [that branch has a HEAD version]`
```

# version 1
invariant forall R:replicaID, B:branch. exists X:version. headVersionOfBranchMapRel(R,B,X) &  graphVersions(R,X)  & setVersions(X) & setBranches(B)

# version 2
invariant forall R:replicaID, B:branch. exists P:replicaID, X:version. headVersionOfBranchMapRel(R,B,X) &  graphVersions(R,X)  & setVersions(X) & branchToReplicaRel(B,P) & setBranches(B)

# version 3
invariant exists X:version. setReplicas(R) & setBranches(B) & branchToReplicaRel(B,R) -> headVersionOfBranchMapRel(Q,B,X) &  graphVersions(Q,X)  & setVersions(X) & setReplicas(Q)

# version 4: 
invariant exists X:version. setReplicas(R) & setBranches(B) & branchToReplicaRel(B,R) & setReplicas(Q)-> headVersionOfBranchMapRel(Q,B,X) &  graphVersions(Q,X)  & setVersions(X) 

```
We observe that there isn't a structure that has been defined to capture the following information: 
**what are the branches that are contained in a given replica at any given time-snapshot?**

The final version that solved the issue: 
```
invariant exists X:version. setReplicas(R) & setBranches(B) & branchToReplicaRel(B,R) & setReplicas(Q) & ~(Q=R) -> headVersionOfBranchMapRel(Q,B,X) &  graphVersions(Q,X)  & setVersions(X) & (branchToReplicaRel(A,Q) & setBranches(A) ) 
```

### Issue 2. The commits are NOT monotonically increasing.


```
#[Issue 2] : The commits are not monotonically increasing for the branches

# monotonically increasing commits
invariant graph_hb.link(R,X,Y) & ( graph_hb.vertex(R,X) & graph_hb.vertex(R,Y) & setReplicas(R) ) & commitsInVersion(X,A) & commitsInVersion(Y,B) -> (setCommitIDs(A) -> setCommitIDs(B) )

```


