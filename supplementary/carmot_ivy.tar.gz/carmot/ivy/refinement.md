# Refinement for Quark with Operational Semantics

## Comparison with Quelea
The `contract sematics` in Quelea, depended explicitly on the lower-level, `trace-semantics`/`trace-history` or the `execution trace E`. The contract-language, enabled one to define contracts with a specific notion of a `trace-execution`. But, the issue with this sort of a system, is that developers/users of systems **do not** ever think about a system, at the level of the `execution trace`. They always think/design and develop systems, at the `high-level application-level specification` and not at the realm of the `low-level execution-trace`. Hence, we need to define and develop the system's specification in a `trace-agnostic` manner. In Quark, we attempt to do this, by first providing an `axiomatic semantics` for the system. And then, to ensure that the `axiomatic semantics` can be realized in practice by an actual machine, we define a `machine/operational-semantics` by which we assert that the properties guaranteed by the `axiomatically defined system` is also guaranteed by the `low-level machine description`.

## Introduction
The basic approach, is to extend the `happensBeforeEqual` structure, to be paramterized by the `replicaID`. In the high-level description, we modelled the system, as ONE global graph. However, the machine semantics of such a system, does not have an absolute global representation, as there is no centralized server. There's just a number of replicas of the machine at different machines. We need to ensure that the dynamics captured by the global-graph model, is also captured by the `refined` lower-level machine based description of the system. 

## Operational Semantics strategy
1. Instead of one copy of (V,E,N,C,H,L) for the entire system, we are going to have one copy per replica. Thus all of (V,E,N,C,H,L) become functions whose first argument is a replica id. For instance, V(i) gives the set of vertices on replica i, N(i,v) gives the value for version v on replica i etc.
2. Each of Commit, Merge, FastFwd and Fork steps are parameterized by replica id. So Commit<i> denotes the commit step on i'th replica.
3. There is a one-to-one mapping between replica ids and branches. So i'th replica only modifies (i.e., pulls into, commits to) the branch b_i.
4. Commit<i> would simply create a new version on b_i. So H(i,b_i) gets updated to the new version. 
5. Add a new rule called Sync<i,j> that finds any new information on replica i and adds it to j. For instance, if H(i,k) is a later version that H(j,k) for any branch k, the H(j,k) is updated with H(i,k). Same is the case with V,E,N,C,L as well.
6. Merge<i> and FastFwd<i> would pull a new version from another branch j onto i. This is implemented using globally synchronized reads, so all of V(i), E(i), N(i), C(i), H(i), and L(i) must be latest (same, or later than the corresponding V,E,N,C,H,L on all other branches).
7. I think Fork can be executed without any coordination like commit, but I am not sure. Write the semantics for the other rules first and then we can think of fork.


### Methodology

In the verification of the high-level model of quark, we reprsented the system as the following state: `(G(V,E), L, H, C, N)` where the following holds: 
1. N-map: maps versions to values ( this captures the replicated data type description)
2. C-map: maps versions to the commits that constitute to the version.
3. L-map : maps the pair of branches to their `lowest common ancestor`
4. H-map: maps the branches to their head version. 
5. G(V,E) : Is a graph of the versions that captures the history of version creation, that each replica is aware of. 
6. Finally, to capture the Happens-Before-Relationship between the versions, we have defined a **NEW** structure in Ivy, which is **absent** from the formal-description of the system in the paper. The `happens-before-equal` graph, captures this complicated relationship between the versions, and it is used in the reasoning processs, as it facilitates the computaiton of the `lowest-common-ancestor`.

It's important to note that the N,C-maps are global maps. However, when considering an actual machine that implements the system, we need to realize that there is **NO GLOBAL** version-map or history. The graphs are all locally present, and every time a graph update happens, we need to ensure that the pre-existing graph-structure in a replica is brought 
into itself, with only the given branch being udpated. 

#### How should we implement this and prove it in Ivy? 

##### Query

I have some confusion about the description of Merge, in the context of the following two rules. 
Add a new rule called Sync<i,j> that finds any new information on replica i and adds it to j. For instance, if H(i,k) is a later version that H(j,k) for any branch k, the H(j,k) is updated with H(i,k). Same is the case with V,E,N,C,L as well.
Merge<i> and FastFwd<i> would pull a new version from another branch j onto i. This is implemented using globally synchronized reads, so all of V(i), E(i), N(i), C(i), H(i), and L(i) must be latest (same, or later than the corresponding V,E,N,C,H,L on all other branches).

Merge<b_i, b_j> : will be merging information contained in replica-j with replica-i. To do so, we would do a globally synchronized reads, so that the destination replica-i, is updated with the all the latest versions from all individual branches.( This requirement forces us to ensure that the replica-i is NOT STALE). The thought-process that I have is that, during the merge-process, the system implementation updates the local-replica, with the `implicit` global-graph of all updates(ie. it is exactly similar as the global-graph used in the HIgh-level proof). And then, it creates a new version locally, as a consequence of merging the two branches. 
However, there is necessarily **NO NEED** for separately defining local L-functions for each replica, as we can use the L-function defined for the global-graph. We only need local H functions. 

Sync<i,j> : Helps to ensure that any new information contained in replica-j is copied into replica-i. Therefore, all the branch information contained in replica-j is updated into replica-i. Now, its important to note that both replica-i and replica-j, may be containing `stale-information` with respect to all other branches i.e. if we had a notion of a Global-Graph for the system( corresponding to the high-level system), the local-graphs on both replica-i and replica-j, will necessarily be a sub-graph of the global-graph.
So, when do we intend to use the command `Sync<i,j>`?? Is this really needed? 

The only way I can think of, for explaining the need for SYNC<I,j> , is that the system model NEVER has access to the `implicit` global-representation of the graph. 
At every instance when the MERGE<I> is invoked, it becomes necessary to do a global synchronization, in which for every (branch k != branch_i) SYNC<i,k> is invoked. 
This would ensure that the branch_i contains NO STALE information. And only then, can we proceed with merging the branch_j with branch_i in replica_i. 

My concern is as follows: How would we know that during the process of synchronization, there are NO COMMITS that occur to any branch which was earlier synchronized? If it did occur, there's a possibility that the Synchronization between ALL-REPLICAS shall never terminate, as the branch_i, WILL NEVER contain the latest wrt some branch_m. During the process of MERGE, do we ensure that the different replicas are NOT available? I believe that's not what you'd explained. The beauty of this system, was that it would always be available for COMMIT and FORK. The global-synchronization would be enforced only for the replica, into which we are pulling information from another replica. The PULL-actions will be delayed, due to global coordination. But, individual commits should be possible at all individual replicas. 

## Implementation
It's possible that when we merge, we do not need the latest-versions for each branch. But rather, we need the latest information regarding the previous merged state. In essence, all the merges are supposed to be serializable. Hence, we need to conduct a `SYNC<i,j>` for all pairs of branches, only to ensure that we have captured in `replica-i` the information contained in the most recent merge that occurred before the current merge call. It's only by doing this, can we ensure the `Unique LCA` property, while also guaranteeing that availablity of each replica for `commits` and `forks`.


###  Update the `happensBeforeEqual` module with `replica`
Update the `happensBeforeEqual` module with `replica-type`(k) as a parameter, alongside the `vertex-type`(t) ie. `module happensBeforeEqual(t, k)`. Additionally, update the definition of `link` and `vertex` as follows:

```
	relation link(R:k,X:t,Y:t)
	relation vertex(R:k, X:t)
```
The invariants that are specified are modified accordingly. 


### Update the `happensBeforeEqual` module with `sync` action
One attempt to facilitate the synchronization of the `happensBeforeEqualRelations` across two different replicas is as follows:
```
	# ----------------------------------------
	# SYNCHRONIZE REPLICAS


	action sync(src:k, dest:k)={
		vertex(dest,X) := vertex(src, X) | vertex(dest, X);
		link(dest, X,Y) := link(src, X, Y) | link(dest, X, Y);
	}
```
This however leads to the violation of the following invariants: 

```
	    invariant vertex(R,X) & vertex(R,Y) & vertex(R,Z) & link(R, X, Y) & link(R, Y, Z) -> link(R, X, Z)  	# Transitivity
	    invariant vertex(R, X) & vertex(R, Y) & link(R, X, Y) & link(R, Y, X) -> X = Y    		# Anti-symmetry 
```
This was resolved by adopting the following changes: 
```
	action updateTransitivity(rep:k)={
		assume vertex(rep,X) & vertex(rep,Y) & vertex(rep,Z) & link(rep, X, Y) & link(rep, Y, Z) -> link(rep, X, Z)
	}

	action updateAntiSymmetry(rep:k)={
		assume vertex(rep, X) & vertex(rep, Y) & link(rep, X, Y) & link(rep, Y, X) -> X = Y
	}

	action sync(src:k, dest:k)={
		vertex(dest,X) := vertex(src, X) | vertex(dest, X);
		link(dest, X,Y) := link(src, X, Y) | link(dest, X, Y);
		call updateTransitivity(dest);
		call updateAntiSymmetry(dest);
	}

```



## Concerns
1. How do we ensure that the `CommitIDs` , `VersionIDs` and `BranchID` are `unique numbers`, since in the real-system the commits are created/initialized in distributed entities?
2. What happens if the REPLICA executing the Master/Main-Branch dies/terminates? 
3. How to define the progress properties : `exists_mergeable` and `quiescentState`, for the low-level machine? 
4. The `Liveness Properties` CANNOT be stated for the Machine-Semantics, because there's no SINGLE replica to which we may compute the `LCA` relationship. The `merged` replica needs to be first computed/evaluated after synchronization, to be able to determine whether there exists a `unique LCA` for a given pair of branches. 
5. The `Safety Properties` CAN be stated easily, as they should HOLD for ALL REPLICAS.
6. We need to determine how to evalute/verify REFINEMENT in IvY.



# Refinement as Implementation in Ivy. 

## 