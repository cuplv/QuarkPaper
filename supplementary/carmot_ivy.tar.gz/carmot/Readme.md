
# Introduction

## Challenge in Ivy implementation

The difficulty is in implementing the Reachability Function. How does one determine if a vertex is reachable from another one? 


```
searching for a small model... done
[
    @X = 0
    root = 1
    @Y = 0
    graph.link(1,1) = true
    graph.link(0,0) = false
    graph.link(0,1) = false
    graph.link(1,0) = false
    graph.vertex(1) = true
    graph.vertex(0) = false
]
call graph.connect

{
    [
        fml:dest = 0
        fml:src = 1
    ]
    happensBeforeEqual.ivy: line 34: assume fml:src ~= fml:dest

    happensBeforeEqual.ivy: line 35: assume (graph.vertex(fml:src) & ~graph.vertex(fml:dest))

    happensBeforeEqual.ivy: line 36: assume ~graph.link(fml:src,fml:dest)

    happensBeforeEqual.ivy: line 38: graph.vertex(fml:dest) := true

    [
        graph.vertex(0) = true
    ]
    happensBeforeEqual.ivy: line 39: graph.link(fml:src,fml:dest) := true

    [
        graph.link(1,0) = true
    ]
    happensBeforeEqual.ivy: line 48: graph.link(fml:dest,fml:dest) := true

    [
        graph.link(0,0) = true
    ]
}



```

There's a problem in defining the invariant over the Graph/Relations when we initialize it with a root-node. Maybe, we shouldn't do that. Maybe it's better to just start clean.



## Modifying Ivy codebase : To handle the LCA relationship as FAU

```

	action updatelca(x:t)={

		if (x ~= root){

			if some m:t. (link(Z,X) & link(Z,Y) & (vertex(X) & vertex(Z) & vertex(Y)) -> vertex(m) & link(Z,m) & link(m,x) & link(m,Y) ) {
				lcAncestor(X,Y,m) := true;
			}else{
				lcAncestor(X,Y,Z) := true;
			};

		}else{
			# a node was deleted. 

		};

		assume ~(exists M. (link(Z,X) & link(Z,Y) & (vertex(X) & vertex(Z) & vertex(Y)) -> vertex(M) & link(Z,M) & link(M,x) & link(M,Y) ) ) -> lcAncestor(X,Y,Z) 
	
	}

```


```
	action updatelca(x:t)={

		# [property] assume ~(exists M. (link(Z,X) & link(Z,Y) & (vertex(X) & vertex(Z) & vertex(Y)) -> vertex(M) & link(Z,M) & link(M,X) & link(M,Y) ) ) -> lcAncestor(X,Y,Z) 

		if vertex(x) {

			if some z:t. ( link(z,x) & link(z,Y) & (vertex(x) & vertex(z) & vertex(Y) ) ){

				if exists M. link(z,M) & (vertex(M) & link(M,x) & link(M,Y) ){
					lcAncestor(x,Y,M) := true;
				}else{
					lcAncestor(x,Y,z) := true;
				};
			};
			
		}else{


		};
	
	}

```

UpdateLCA in Quark2.

```
	action updateLCA(src:branch, dest:branch, op: edgeOps)={

		if(op = fork){

			# -- Relational Description
			lcAncestorRel(dest, Y, Z) := lcAncestorRel(src,Y,Z);
			lcAncestorRel(Y, dest, Z) := lcAncestorRel(Y, src, Z);

			prev_head_version := headVersionOfBranch(src);
			lcAncestorRel(src, dest, prev_head_version) := true;
			lcAncestorRel(dest, src, prev_head_version) := true;


			# -- Functional Description
			lcAncestorFunc(dest, Y) := lcAncestorFunc(src,Y);
			lcAncestorFunc(Y, dest) := lcAncestorFunc(Y, src);

			prev_head_version := headVersionOfBranch(src);
			lcAncestorFunc(src, dest) := prev_head_version;
			lcAncestorFunc(dest, src) := prev_head_version;			
		};

		if (op = fstfwd){

			# -- Relational Description
			assume lcAncestorRel(dest,B,Y) & lcAncestorRel(src,B,Z) & graph.link(Y,Z) -> (lcAncestorRel(dest, B, Z) = lcAncestorRel(src,B,Z) ) & (lcAncestorRel(B, dest, Z) = lcAncestorRel(B, src, Z));

			prev_head_version := headVersionOfBranch(src);
			lcAncestorRel(src, dest, prev_head_version) := true;
			lcAncestorRel(dest, src, prev_head_version) := true;

		};

		if (op = merge){

			# -- Relational Description
			assume lcAncestorRel(dest,B,Y) & lcAncestorRel(src,B,Z) & graph.link(Y,Z) -> (lcAncestorRel(dest, B, Z) = lcAncestorRel(src,B,Z) ) & (lcAncestorRel(B, dest, Z) = lcAncestorRel(B, src, Z));

			prev_head_version := headVersionOfBranch(src);
			lcAncestorRel(src, dest, prev_head_version) := true;
			lcAncestorRel(dest, src, prev_head_version) := true;


		};



	}

		after updateLCA{

			# assume( forall X,Y.  X~=Y -> (lcAncestor(X,Y) = graph.lca( headVersionOfBranch(X), headVersionOfBranch(Y) ) ) ) 

			#if(exists X:branch,Y. setBranches(X) & setBranches(Y) & X~=Y ){
			#	lcAncestor(X,Y) := graph.lca( headVersionOfBranch(X), headVersionOfBranch(Y) );
			#}



	}


```

